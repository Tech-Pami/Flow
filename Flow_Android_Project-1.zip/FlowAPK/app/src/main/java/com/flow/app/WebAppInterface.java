package com.flow.app;

import android.app.AlarmManager;
import android.app.AppOpsManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

public class WebAppInterface {
  private final Context ctx;

  WebAppInterface(Context context) {
    this.ctx = context;
  }

  // id: stable string id per to-do (used to cancel later)
  // title/body: notification text
  // triggerAtMillis: absolute epoch time in ms when it should fire
  @JavascriptInterface
  public void scheduleAlarm(String id, String title, String body, long triggerAtMillis) {
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;

    int notifId = id.hashCode();
    Intent intent = new Intent(ctx, AlarmReceiver.class);
    intent.putExtra("title", title);
    intent.putExtra("body", body);
    intent.putExtra("notifId", notifId);

    PendingIntent pi = PendingIntent.getBroadcast(
        ctx, notifId, intent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (am.canScheduleExactAlarms()) {
          am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        } else {
          am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        }
      } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
      }
    } catch (SecurityException e) {
      // Missing exact-alarm permission; fall back to inexact so it still fires eventually.
      am.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
    }
  }

  @JavascriptInterface
  public void cancelAlarm(String id) {
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;
    int notifId = id.hashCode();
    Intent intent = new Intent(ctx, AlarmReceiver.class);
    PendingIntent pi = PendingIntent.getBroadcast(
        ctx, notifId, intent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    am.cancel(pi);
  }

  // Lets JS check whether exact alarms are allowed (Android 12+) and prompt the user if not.
  @JavascriptInterface
  public boolean canScheduleExactAlarms() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
      return am != null && am.canScheduleExactAlarms();
    }
    return true;
  }

  @JavascriptInterface
  public void openExactAlarmSettings() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
      intent.setData(Uri.parse("package:" + ctx.getPackageName()));
      intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      ctx.startActivity(intent);
    }
  }

  @JavascriptInterface
  public boolean hasNotificationPermission() {
    return androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled();
  }

  @JavascriptInterface
  public void openNotificationSettings() {
    Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
    intent.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.getPackageName());
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    ctx.startActivity(intent);
  }

  // ---- Focus Mode / app blocking ----

  @JavascriptInterface
  public boolean hasUsageAccess() {
    AppOpsManager aom = (AppOpsManager) ctx.getSystemService(Context.APP_OPS_SERVICE);
    if (aom == null) return false;
    int mode;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      mode = aom.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.getPackageName());
    } else {
      mode = aom.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.getPackageName());
    }
    return mode == AppOpsManager.MODE_ALLOWED;
  }

  @JavascriptInterface
  public void openUsageAccessSettings() {
    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    ctx.startActivity(intent);
  }

  // Returns JSON array of {package,label} for launchable, non-Flow apps.
  @JavascriptInterface
  public String getInstalledApps() {
    PackageManager pm = ctx.getPackageManager();
    Intent launcherIntent = new Intent(Intent.ACTION_MAIN);
    launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER);
    List<ResolveInfo> apps = pm.queryIntentActivities(launcherIntent, 0);
    JSONArray out = new JSONArray();
    try {
      for (ResolveInfo ri : apps) {
        String pkg = ri.activityInfo.packageName;
        if (pkg.equals(ctx.getPackageName())) continue;
        ApplicationInfo ai = ri.activityInfo.applicationInfo;
        boolean isSystem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
            && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
        if (isSystem) continue; // skip system apps to keep the picker to apps the user actually installed
        JSONObject o = new JSONObject();
        o.put("package", pkg);
        o.put("label", ri.loadLabel(pm).toString());
        out.put(o);
      }
    } catch (Exception ignored) {}
    return out.toString();
  }

  // packagesJson: '["com.x","com.y"]'  durationMinutes: session length
  @JavascriptInterface
  public void startFocusSession(String packagesJson, int durationMinutes) {
    long endTime = System.currentTimeMillis() + (durationMinutes * 60_000L);
    Intent i = new Intent(ctx, FocusService.class);
    i.putExtra("packages", packagesJson);
    i.putExtra("endTime", endTime);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i);
    else ctx.startService(i);
  }

  @JavascriptInterface
  public void stopFocusSession() {
    ctx.stopService(new Intent(ctx, FocusService.class));
    ctx.getSharedPreferences(FocusService.PREFS, Context.MODE_PRIVATE)
        .edit().putBoolean("active", false).apply();
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    if (am != null) {
      Intent stop = new Intent(ctx, FocusStopReceiver.class);
      PendingIntent pi = PendingIntent.getBroadcast(ctx, 9002, stop,
          PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
      am.cancel(pi);
    }
  }

  // Returns JSON: {active, endTime, packages: [...]}
  @JavascriptInterface
  public String getFocusStatus() {
    SharedPreferences prefs = ctx.getSharedPreferences(FocusService.PREFS, Context.MODE_PRIVATE);
    boolean active = prefs.getBoolean("active", false);
    long endTime = prefs.getLong("endTime", 0);
    if (active && System.currentTimeMillis() >= endTime) active = false;
    JSONObject o = new JSONObject();
    try {
      o.put("active", active);
      o.put("endTime", endTime);
      o.put("packages", new JSONArray(prefs.getString("packages", "[]")));
    } catch (Exception ignored) {}
    return o.toString();
  }
}
