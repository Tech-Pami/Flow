import os, shutil
base = 'fnt/node_modules/@fontsource'
fam = {'fraunces': 'Fraunces', 'instrument-sans': 'Instrument Sans', 'open-sans': 'Open Sans', 'arimo': 'Arimo',
       'inter': 'Inter', 'comfortaa': 'Comfortaa', 'patrick-hand': 'Patrick Hand', 'dancing-script': 'Dancing Script',
       'kalam': 'Kalam', 'caveat': 'Caveat', 'ibm-plex-mono': 'IBM Plex Mono'}
out = 'app/src/main/assets/'
os.makedirs(out + 'fonts', exist_ok=True)
css = ''
for i, n in fam.items():
    for w, alts in ((400, (400,)), (600, (600, 700))):
        for a in alts:
            f = f'{base}/{i}/files/{i}-latin-{a}-normal.woff2'
            if os.path.exists(f):
                shutil.copy(f, out + f'fonts/{i}-{w}.woff2')
                css += "@font-face{font-family:'%s';font-weight:%d;font-style:normal;font-display:swap;src:url(fonts/%s-%d.woff2) format('woff2')}\n" % (n, w, i, w)
                break
open(out + 'fonts.css', 'w').write(css)
print('fonts bundled')
