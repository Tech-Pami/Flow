import hashlib, os, re, sys, time, urllib.request

UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36'
FAM = ['Fraunces:wght@400;600', 'Instrument+Sans:wght@400;600', 'Open+Sans:wght@400;600', 'Arimo:wght@400;600',
       'Inter:wght@400;600', 'Comfortaa:wght@400;600', 'Patrick+Hand', 'Dancing+Script:wght@400;600',
       'Kalam:wght@400;700', 'Caveat:wght@400;600', 'IBM+Plex+Mono:wght@400;500']
OUT = 'app/src/main/assets/'


def get(u):
    for i in range(3):
        try:
            return urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': UA}), timeout=40).read()
        except Exception:
            if i == 2:
                raise
            time.sleep(2 * (i + 1))


os.makedirs(OUT + 'fonts', exist_ok=True)
css, n = '', 0
for f in FAM:
    try:
        t = get('https://fonts.googleapis.com/css2?family=' + f + '&display=swap').decode()
    except Exception as e:
        print('FAILED css', f, e)
        continue
    for m in re.finditer(r'/\* latin \*/\s*(@font-face\s*\{.*?\})', t, re.S):
        blk = m.group(1)
        u = re.search(r'url\([\'"]?(https://[^)\'"]+)[\'"]?\)', blk).group(1)
        name = hashlib.md5(u.encode()).hexdigest()[:12] + '.woff2'
        try:
            if not os.path.exists(OUT + 'fonts/' + name):
                open(OUT + 'fonts/' + name, 'wb').write(get(u))
        except Exception as e:
            print('FAILED file', u, e)
            continue
        css += blk.replace(u, 'fonts/' + name) + '\n'
        n += 1
open(OUT + 'fonts.css', 'w').write(css)
print('fonts bundled:', n)
if n < 15:
    print('FAILED: only', n, 'font files bundled')
    sys.exit(1)
