package com.flow.student

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import org.json.JSONArray
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.time.LocalDate

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pending = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 9)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) =
                loader.shouldInterceptRequest(r.url)
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun schedule(json: String) { Notifier.schedule(this@MainActivity, json) }

        @JavascriptInterface
        fun focus(until: Double, total: Double, allowed: String, subj: String) {
            getSharedPreferences("w", 0).edit().putLong("fu", until.toLong()).putLong("ft", total.toLong())
                .putString("fa", allowed).putString("fs", subj).putLong("fp", 0).apply()
        }

        @JavascriptInterface
        fun apps(): String {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = packageManager.queryIntentActivities(i, 0)
                .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
                .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
            val a = JSONArray()
            list.forEach { a.put(JSONObject().put("p", it.first).put("n", it.second)) }
            return a.toString()
        }

        @JavascriptInterface
        fun axSettings() = runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        @JavascriptInterface
        fun appSettings() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface
        fun summary(json: String) {
            getSharedPreferences("w", 0).edit().putString("s", json).apply()
            FlowWidget.refresh(this@MainActivity)
        }

        @JavascriptInterface
        fun exportData(json: String) = runOnUiThread {
            pending = json
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "flow-backup-${LocalDate.now()}.json")
            }
            startActivityForResult(i, 1)
        }

        @JavascriptInterface
        fun importData() = runOnUiThread {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(i, 2)
        }
    }

    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        val u = d?.data
        if (res != RESULT_OK || u == null) return
        if (req == 1) contentResolver.openOutputStream(u)?.use { it.write(pending.toByteArray()) }
        if (req == 2) {
            val t = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } ?: ""
            web.evaluateJavascript("window.onImport(" + JSONObject.quote(t) + ")", null)
        }
    }
}
