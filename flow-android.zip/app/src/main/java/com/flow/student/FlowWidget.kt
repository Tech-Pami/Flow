package com.flow.student

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject
import java.time.LocalDate

class FlowWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, views(c)) }
    }

    companion object {
        fun views(c: Context): RemoteViews {
            val o = try {
                JSONObject(c.getSharedPreferences("w", 0).getString("s", "{}") ?: "{}")
            } catch (e: Exception) { JSONObject() }
            val v = RemoteViews(c.packageName, R.layout.widget)
            val fresh = o.optString("k") == LocalDate.now().toString()
            v.setTextViewText(R.id.pct, if (fresh) "${o.optInt("p")}%" else "Flow")
            v.setTextViewText(R.id.sub, if (fresh) "${o.optInt("d")} of ${o.optInt("t")} habits" else "Open to update")
            v.setTextViewText(R.id.stk, "Streak ${o.optInt("s")} days")
            val t = skin(c, v)
            v.setTextColor(R.id.pct, t.ink)
            v.setTextColor(R.id.sub, t.ac)
            v.setTextColor(R.id.stk, t.mu)
            v.setOnClickPendingIntent(R.id.root,
                PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            return v
        }

        class Th(val cd: Int, val ink: Int, val mu: Int, val ac: Int, val ln: Int, val sq: Boolean)

        fun theme(c: Context): Th {
            val o = data(c).optJSONObject("c")
            fun col(k: String, d: Int): Int = try { Color.parseColor(o!!.optString(k)) } catch (e: Exception) { d }
            return Th(col("cd", 0xFF252A31.toInt()), col("ink", 0xFFE6E8EA.toInt()), col("mu", 0xFF8A9199.toInt()),
                col("ac", 0xFF9DB4C8.toInt()), col("ln", 0xFF39414A.toInt()), o?.optInt("sq") == 1)
        }

        fun skin(c: Context, v: RemoteViews): Th {
            val t = theme(c)
            v.setInt(R.id.fr, "setColorFilter", t.cd)
            v.setInt(R.id.fs, "setColorFilter", t.cd)
            v.setInt(R.id.bs, "setColorFilter", t.ln)
            v.setViewVisibility(R.id.fr, if (t.sq) View.GONE else View.VISIBLE)
            v.setViewVisibility(R.id.fs, if (t.sq) View.VISIBLE else View.GONE)
            v.setViewVisibility(R.id.bs, if (t.sq) View.VISIBLE else View.GONE)
            return t
        }

        fun data(c: Context): JSONObject = try {
            JSONObject(c.getSharedPreferences("w", 0).getString("s", "{}") ?: "{}")
        } catch (e: Exception) { JSONObject() }

        fun open(c: Context): PendingIntent =
            PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

        fun refresh(c: Context) {
            TasksWidget.refresh(c)
            TrendWidget.refresh(c)
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, FlowWidget::class.java))
            if (ids.isNotEmpty()) m.updateAppWidget(ids, views(c))
        }
    }
}
