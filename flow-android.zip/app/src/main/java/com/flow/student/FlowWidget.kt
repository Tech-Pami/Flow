package com.flow.student

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject
import java.time.LocalDate

class FlowWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, views(c)) }
    }

    companion object {
        fun views(c: Context): RemoteViews {
            val o = try {
                JSONObject(c.getSharedPreferences("w", 0).getString("s", "{}") ?: "{}")
            } catch (e: Exception) { JSONObject() }
            val v = RemoteViews(c.packageName, R.layout.widget)
            val fresh = o.optString("k") == LocalDate.now().toString()
            v.setTextViewText(R.id.pct, if (fresh) "${o.optInt("p")}%" else "Flow")
            v.setTextViewText(R.id.sub, if (fresh) "${o.optInt("d")} of ${o.optInt("t")} habits" else "Open to update")
            v.setTextViewText(R.id.stk, "Streak ${o.optInt("s")} days")
            v.setOnClickPendingIntent(R.id.root,
                PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            return v
        }

        fun data(c: Context): JSONObject = try {
            JSONObject(c.getSharedPreferences("w", 0).getString("s", "{}") ?: "{}")
        } catch (e: Exception) { JSONObject() }

        fun open(c: Context): PendingIntent =
            PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

        fun refresh(c: Context) {
            TasksWidget.refresh(c)
            TrendWidget.refresh(c)
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, FlowWidget::class.java))
            if (ids.isNotEmpty()) m.updateAppWidget(ids, views(c))
        }
    }
}
