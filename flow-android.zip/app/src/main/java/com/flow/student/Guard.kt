package com.flow.student

import android.content.Context

object Guard {
    fun on(c: Context): Boolean = c.getSharedPreferences("w", 0).getBoolean("gd", false)

    fun set(c: Context, v: Boolean) {
        val s = c.getSharedPreferences("w", 0)
        val e = s.edit().putBoolean("gd", v)
        if (v && s.getLong("fu", 0) <= System.currentTimeMillis()) e.putLong("fp", 0).putBoolean("t5", false)
        e.apply()
    }
}
