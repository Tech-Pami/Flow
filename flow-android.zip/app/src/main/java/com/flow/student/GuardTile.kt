package com.flow.student

import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class GuardTile : TileService() {
    override fun onStartListening() { paint() }

    override fun onClick() {
        Guard.set(this, !Guard.on(this))
        paint()
    }

    private fun paint() {
        val t = qsTile ?: return
        val on = Guard.on(this)
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Guard"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "On" else "Off"
        t.icon = Icon.createWithResource(this, R.drawable.ic_guard)
        t.updateTile()
    }
}
