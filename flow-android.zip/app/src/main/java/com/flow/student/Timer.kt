package com.flow.student

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

object Timer {
    private const val ID = 777

    fun start(c: Context, sub: String, mins: Int, start: Long) {
        c.getSharedPreferences("w", 0).edit().putLong("ts", start).putString("tsub", sub).apply()
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("timer", "Focus timer", NotificationManager.IMPORTANCE_LOW))
        fun act(code: Int, name: String) = PendingIntent.getBroadcast(
            c, code, Intent(c, TimerReceiver::class.java).setAction(name),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "timer").setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setContentTitle(sub).setContentText("Focus timer running")
            .setUsesChronometer(true).setWhen(start).setShowWhen(true).setOngoing(true)
            .setContentIntent(FlowWidget.open(c))
            .addAction(android.R.drawable.ic_menu_save, "Stop and log", act(1001, "log"))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Discard", act(1002, "drop"))
            .build()
        nm.notify(ID, n)
        val done = PendingIntent.getBroadcast(
            c, 1003,
            Intent(c, AlarmReceiver::class.java).putExtra("t", "Focus block finished")
                .putExtra("b", "$sub is done. Stop and log when you are ready.").putExtra("i", 778),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        c.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, start + mins * 60000L, done)
    }

    fun stop(c: Context, log: Boolean) {
        val s = c.getSharedPreferences("w", 0)
        val st = s.getLong("ts", 0)
        if (log && st > 0) {
            val m = ((System.currentTimeMillis() - st) / 60000).toInt()
            if (m >= 1) {
                val a = try { JSONArray(s.getString("plog", "[]")) } catch (e: Exception) { JSONArray() }
                a.put(JSONObject().put("d", LocalDate.now().toString()).put("m", m).put("sub", s.getString("tsub", "General")))
                s.edit().putString("plog", a.toString()).apply()
            }
        }
        s.edit().remove("ts").putLong("fu", 0).apply()
        c.getSystemService(NotificationManager::class.java).cancel(ID)
        PendingIntent.getBroadcast(c, 1003, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let {
            c.getSystemService(AlarmManager::class.java).cancel(it); it.cancel()
        }
    }
}

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Timer.stop(c, i.action == "log") }
}
