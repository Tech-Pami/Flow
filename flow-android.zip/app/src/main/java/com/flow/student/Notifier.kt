package com.flow.student

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray

object Notifier {
    fun show(c: Context, id: Int, title: String, body: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("flow", "Reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val n = Notification.Builder(c, "flow").setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title).setContentText(body)
            .setContentIntent(FlowWidget.open(c)).setAutoCancel(true).build()
        nm.notify(id, n)
    }

    fun schedule(c: Context, json: String) {
        val am = c.getSystemService(AlarmManager::class.java)
        for (i in 0 until 60) {
            PendingIntent.getBroadcast(c, i, Intent(c, AlarmReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let { am.cancel(it); it.cancel() }
        }
        val a = try { JSONArray(json) } catch (e: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        for (i in 0 until minOf(a.length(), 60)) {
            val r = a.getJSONArray(i)
            if (r.getLong(0) <= now) continue
            val it = Intent(c, AlarmReceiver::class.java)
                .putExtra("t", r.getString(1)).putExtra("b", r.getString(2)).putExtra("i", i)
            val pi = PendingIntent.getBroadcast(c, i, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.getLong(0), pi)
        }
        c.getSharedPreferences("w", 0).edit().putString("sched", json).apply()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifier.show(c, i.getIntExtra("i", 0), i.getStringExtra("t") ?: "Flow", i.getStringExtra("b") ?: "")
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifier.schedule(c, c.getSharedPreferences("w", 0).getString("sched", "[]") ?: "[]")
    }
}
