package com.flow.student

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.widget.RemoteViews

class TrendWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, views(c)) }
    }

    companion object {
        fun views(c: Context): RemoteViews {
            val a = FlowWidget.data(c).optJSONArray("tr")
            val w = 480
            val h = 220
            val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bm)
            val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF39414A.toInt(); strokeWidth = 2f }
            for (i in 0..2) cv.drawLine(0f, 10f + i * 100f, w.toFloat(), 10f + i * 100f, grid)
            var avg = 0
            if (a != null && a.length() > 1) {
                val n = a.length()
                val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFF9DB4C8.toInt(); style = Paint.Style.STROKE; strokeWidth = 7f
                    strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
                }
                val path = Path()
                var sum = 0
                var lx = 0f
                var ly = 0f
                for (i in 0 until n) {
                    val p = a.optInt(i)
                    sum += p
                    lx = 12f + i * (w - 24f) / (n - 1)
                    ly = h - 12f - (p / 100f) * (h - 24f)
                    if (i == 0) path.moveTo(lx, ly) else path.lineTo(lx, ly)
                }
                cv.drawPath(path, line)
                cv.drawCircle(lx, ly, 10f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE6E8EA.toInt() })
                avg = sum / n
            }
            val v = RemoteViews(c.packageName, R.layout.widget_trend)
            v.setImageViewBitmap(R.id.img, bm)
            v.setTextViewText(R.id.ttl, "Last 14 days, average $avg%")
            v.setOnClickPendingIntent(R.id.root, FlowWidget.open(c))
            return v
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, TrendWidget::class.java))
            if (ids.isNotEmpty()) m.updateAppWidget(ids, views(c))
        }
    }
}
