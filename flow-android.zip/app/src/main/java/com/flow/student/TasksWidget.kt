package com.flow.student

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews

class TasksWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        ids.forEach { m.updateAppWidget(it, views(c)) }
    }

    companion object {
        fun views(c: Context): RemoteViews {
            val a = FlowWidget.data(c).optJSONArray("tk")
            val text = if (a == null || a.length() == 0) "Nothing planned"
            else (0 until a.length()).joinToString("\n") { "\u25CB  " + a.getString(it) }
            val v = RemoteViews(c.packageName, R.layout.widget_tasks)
            v.setTextViewText(R.id.tl, text)
            val th = FlowWidget.skin(c, v)
            v.setTextColor(R.id.ttl, th.ink)
            v.setTextColor(R.id.tl, th.ac)
            v.setOnClickPendingIntent(R.id.root, FlowWidget.open(c))
            return v
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, TasksWidget::class.java))
            if (ids.isNotEmpty()) m.updateAppWidget(ids, views(c))
        }
    }
}
