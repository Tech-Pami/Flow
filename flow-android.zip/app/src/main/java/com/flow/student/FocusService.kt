package com.flow.student

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray

class RingView(c: Context) : View(c) {
    var frac = 1f
    var label = ""
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF39414A.toInt() }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF9DB4C8.toInt(); strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE6E8EA.toInt(); textAlign = Paint.Align.CENTER; typeface = Typeface.SERIF }

    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        track.strokeWidth = 10 * d
        arc.strokeWidth = 10 * d
        val r = RectF(10 * d, 10 * d, width - 10 * d, height - 10 * d)
        cv.drawOval(r, track)
        cv.drawArc(r, -90f, 360f * frac, false, arc)
        txt.textSize = 44 * d
        val maxW = (width - 20 * d) * 0.62f
        val mw = txt.measureText(label)
        if (mw > maxW && mw > 0) txt.textSize = 44 * d * maxW / mw
        cv.drawText(label, width / 2f, height / 2f - (txt.ascent() + txt.descent()) / 2f, txt)
    }
}

class FocusService : AccessibilityService() {
    private var root: FrameLayout? = null
    private var ring: RingView? = null
    private var cur = Rect()
    private var unknown = false
    private var blockedPkg = ""
    private val h = Handler(Looper.getMainLooper())
    private var grace = 0L
    private val shows = ArrayDeque<Long>()
    private val tick = object : Runnable {
        override fun run() {
            val s = getSharedPreferences("w", 0)
            val left = s.getLong("fu", 0) - System.currentTimeMillis()
            if (left <= 0) { hide(); return }
            evaluate()
            if (root == null) return
            val tot = s.getLong("ft", 1).coerceAtLeast(1)
            ring?.frac = (left.toFloat() / tot).coerceIn(0f, 1f)
            val sec = left / 1000
            ring?.label = "%02d:%02d".format(sec / 60, sec % 60)
            ring?.invalidate()
            h.postDelayed(this, 1000)
        }
    }

    override fun onInterrupt() { hideNow() }

    override fun onUnbind(intent: Intent?): Boolean { hideNow(); return super.onUnbind(intent) }

    override fun onDestroy() { hideNow(); super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            e.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) evaluate()
    }

    private fun isBlocked(p: String, s: SharedPreferences): Boolean {
        if (p == packageName || p.contains("inputmethod") || p.contains("keyboard") || p.contains("honeyboard")) return false
        if (p == "android" || p in PLUMBING) return false
        return !allowed(p, s)
    }

    private val PLUMBING = setOf(
        "com.android.systemui", "com.android.intentresolver", "com.android.permissioncontroller",
        "com.google.android.permissioncontroller", "com.android.documentsui", "com.google.android.documentsui",
        "com.samsung.android.app.sharelive", "com.samsung.android.app.taskedge", "com.samsung.android.app.cocktailbarservice",
        "com.samsung.android.app.clipboardedge", "com.samsung.android.smartcallprovider"
    )

    private fun covered(b: Rect, above: List<Rect>): Boolean {
        val area = b.width().toLong() * b.height()
        for (a in above) {
            val i = Rect()
            if (i.setIntersect(a, b) && i.width().toLong() * i.height() >= area * 0.9) return true
        }
        return false
    }

    private fun scan(s: SharedPreferences): Rect? {
        unknown = false
        blockedPkg = ""
        val above = ArrayList<Rect>()
        var out: Rect? = null
        var seen = false
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                if (Build.VERSION.SDK_INT >= 26 && w.isInPictureInPictureMode) continue
                val b = Rect()
                w.getBoundsInScreen(b)
                if (b.isEmpty) continue
                if (covered(b, above)) continue
                above.add(b)
                val p = w.root?.packageName?.toString() ?: continue
                seen = true
                if (isBlocked(p, s)) {
                    if (blockedPkg.isEmpty()) blockedPkg = p
                    val o = out
                    if (o == null) out = Rect(b) else o.union(b)
                }
            }
        } catch (x: Exception) {}
        if (!seen) {
            val p = rootInActiveWindow?.packageName?.toString()
            if (p == null) { unknown = true; return null }
            if (!isBlocked(p, s)) return null
            blockedPkg = p
            val d = resources.displayMetrics
            return Rect(0, 0, d.widthPixels, d.heightPixels)
        }
        return out
    }

    private fun evaluate() {
        val s = getSharedPreferences("w", 0)
        val now = System.currentTimeMillis()
        if (now >= s.getLong("fu", 0) || now < s.getLong("fp", 0)) { hide(); return }
        if (now < grace) return
        val r = scan(s)
        if (unknown) return
        if (r == null) { hide(); return }
        show(s.getString("fs", "Focus") ?: "Focus", r)
    }

    private fun allowed(p: String, s: SharedPreferences): Boolean {
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        if (p == home || p == "com.android.settings" || p.contains("incallui") || p.contains("dialer") || p.contains("telecom")) return true
        val a = try { JSONArray(s.getString("fa", "[]")) } catch (x: Exception) { JSONArray() }
        for (i in 0 until a.length()) if (a.getString(i) == p) return true
        return false
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, sz: Float, color: Int, top: Int) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(color); gravity = Gravity.CENTER; setPadding(0, dp(top), 0, 0)
    }

    private fun move(r: Rect) {
        val v = root ?: return
        if (r == cur) return
        cur = Rect(r)
        try {
            val lp = v.layoutParams as WindowManager.LayoutParams
            lp.x = r.left; lp.y = r.top; lp.width = r.width(); lp.height = r.height()
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(v, lp)
        } catch (x: Exception) {}
    }

    private fun show(subject: String, r: Rect) {
        if (root != null) { move(r); return }
        val now = System.currentTimeMillis()
        shows.addLast(now)
        while (shows.isNotEmpty() && now - shows.first() > 20000) shows.removeFirst()
        if (shows.size >= 5) {
            getSharedPreferences("w", 0).edit().putLong("fp", now + 120000).apply()
            shows.clear()
            return
        }
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val bp = blockedPkg
        val bn = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(bp, 0)).toString() } catch (x: Exception) { bp }
        val side = minOf(dp(260), minOf(r.width(), r.height()) * 70 / 100)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val rv = RingView(this)
        ring = rv
        col.addView(rv, LinearLayout.LayoutParams(side, side))
        col.addView(label(subject, 22f, 0xFFE6E8EA.toInt(), 20).apply { typeface = Typeface.SERIF })
        col.addView(label("Stay with it. It is nearly done.", 15f, 0xFF8A9199.toInt(), 8))
        col.addView(label("Blocked: $bn", 12f, 0xFF6F7C86.toInt(), 6))
        val back = label("Back to Flow", 16f, 0xFF1C2025.toInt(), 0).apply {
            setPadding(dp(32), dp(14), dp(32), dp(14))
            background = GradientDrawable().apply { setColor(0xFF9DB4C8.toInt()); cornerRadius = dp(28).toFloat() }
            setOnClickListener {
                grace = System.currentTimeMillis() + 1500
                startActivity(Intent(this@FocusService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                hide()
            }
        }
        col.addView(back, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(28) })
        val soft = label("Take 5 minutes", 14f, 0xFF8A9199.toInt(), 0).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener {
                getSharedPreferences("w", 0).edit().putLong("fp", System.currentTimeMillis() + 300000).apply()
                hide()
            }
        }
        col.addView(soft, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        val always = label("Always allow this app", 12f, 0xFF6F7C86.toInt(), 0).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener {
                val sp = getSharedPreferences("w", 0)
                val a = try { JSONArray(sp.getString("fa", "[]")) } catch (x: Exception) { JSONArray() }
                a.put(bp)
                sp.edit().putString("fa", a.toString()).apply()
                hide()
            }
        }
        col.addView(always, LinearLayout.LayoutParams(-2, -2))
        val fl = FrameLayout(this)
        fl.setBackgroundColor(0xE61C2025.toInt())
        fl.addView(col, FrameLayout.LayoutParams(-1, -1))
        val lp = WindowManager.LayoutParams(
            r.width(), r.height(), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left
        lp.y = r.top
        if (Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 40
        }
        fl.alpha = 0f
        fl.translationY = -dp(40).toFloat()
        wm.addView(fl, lp)
        root = fl
        cur = Rect(r)
        fl.animate().alpha(1f).translationY(0f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()
        h.removeCallbacks(tick)
        h.post(tick)
    }

    private fun detach(r: View) {
        try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeViewImmediate(r) } catch (x: Exception) {}
    }

    private fun hide() {
        h.removeCallbacks(tick)
        val r = root ?: return
        root = null
        ring = null
        try {
            val lp = r.layoutParams as WindowManager.LayoutParams
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(r, lp)
        } catch (x: Exception) {}
        r.animate().alpha(0f).setDuration(120).start()
        h.postDelayed({ detach(r) }, 160)
    }

    private fun hideNow() {
        h.removeCallbacksAndMessages(null)
        val r = root ?: return
        root = null
        ring = null
        detach(r)
    }
}
