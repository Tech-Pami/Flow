package com.flow.student

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray

class RingView(c: Context) : View(c) {
    var frac = 1f
    var label = ""
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF39414A.toInt() }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF9DB4C8.toInt(); strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE6E8EA.toInt(); textAlign = Paint.Align.CENTER; typeface = Typeface.SERIF }

    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        track.strokeWidth = 10 * d
        arc.strokeWidth = 10 * d
        txt.textSize = 44 * d
        val r = RectF(10 * d, 10 * d, width - 10 * d, height - 10 * d)
        cv.drawOval(r, track)
        cv.drawArc(r, -90f, 360f * frac, false, arc)
        cv.drawText(label, width / 2f, height / 2f + 15 * d, txt)
    }
}

class FocusService : AccessibilityService() {
    private var root: FrameLayout? = null
    private var ring: RingView? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val s = getSharedPreferences("w", 0)
            val left = s.getLong("fu", 0) - System.currentTimeMillis()
            if (left <= 0) { hide(); return }
            val tot = s.getLong("ft", 1).coerceAtLeast(1)
            ring?.frac = (left.toFloat() / tot).coerceIn(0f, 1f)
            val sec = left / 1000
            ring?.label = "%02d:%02d".format(sec / 60, sec % 60)
            ring?.invalidate()
            h.postDelayed(this, 1000)
        }
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        val s = getSharedPreferences("w", 0)
        val now = System.currentTimeMillis()
        if (now >= s.getLong("fu", 0) || now < s.getLong("fp", 0)) { hide(); return }
        if (p == packageName) {
            if (e.className?.toString()?.contains("MainActivity") == true) hide()
            return
        }
        if (p == "com.android.systemui" || p.contains("inputmethod") || p.contains("keyboard")) return
        if (allowed(p, s)) { hide(); return }
        show(s.getString("fs", "Focus") ?: "Focus")
    }

    private fun allowed(p: String, s: SharedPreferences): Boolean {
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        if (p == home || p == "com.android.settings" || p.contains("incallui") || p.contains("dialer") || p.contains("telecom")) return true
        val a = try { JSONArray(s.getString("fa", "[]")) } catch (x: Exception) { JSONArray() }
        for (i in 0 until a.length()) if (a.getString(i) == p) return true
        return false
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, sz: Float, color: Int, top: Int) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(color); gravity = Gravity.CENTER; setPadding(0, dp(top), 0, 0)
    }

    private fun show(subject: String) {
        if (root != null) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val rv = RingView(this)
        ring = rv
        col.addView(rv, LinearLayout.LayoutParams(dp(240), dp(240)))
        col.addView(label(subject, 22f, 0xFFE6E8EA.toInt(), 24).apply { typeface = Typeface.SERIF })
        col.addView(label("Stay with it. It is nearly done.", 15f, 0xFF8A9199.toInt(), 8))
        val back = label("Back to Flow", 16f, 0xFF1C2025.toInt(), 0).apply {
            setPadding(dp(32), dp(14), dp(32), dp(14))
            background = GradientDrawable().apply { setColor(0xFF9DB4C8.toInt()); cornerRadius = dp(28).toFloat() }
            setOnClickListener {
                startActivity(Intent(this@FocusService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                hide()
            }
        }
        col.addView(back, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(36) })
        val soft = label("Take 5 minutes", 14f, 0xFF8A9199.toInt(), 0).apply {
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener {
                getSharedPreferences("w", 0).edit().putLong("fp", System.currentTimeMillis() + 300000).apply()
                hide()
            }
        }
        col.addView(soft, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        val fl = FrameLayout(this)
        fl.setBackgroundColor(0xE61C2025.toInt())
        fl.addView(col, FrameLayout.LayoutParams(-1, -1))
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 40
        }
        wm.addView(fl, lp)
        root = fl
        fl.post {
            fl.translationY = -fl.height.toFloat()
            fl.animate().translationY(0f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        }
        h.removeCallbacks(tick)
        h.post(tick)
    }

    private fun hide() {
        h.removeCallbacks(tick)
        val r = root ?: return
        root = null
        ring = null
        r.animate().translationY(-r.height.toFloat()).setDuration(180).withEndAction {
            try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(r) } catch (x: Exception) {}
        }.start()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        super.onDestroy()
    }
}
