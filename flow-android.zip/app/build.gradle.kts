plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.flow.student"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.flow.student"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.webkit:webkit:1.11.0") }

val bundleFonts by tasks.registering(Exec::class) {
    workingDir = rootProject.projectDir
    commandLine("python3", "tools/fonts.py")
    isIgnoreExitValue = true
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(bundleFonts) }
