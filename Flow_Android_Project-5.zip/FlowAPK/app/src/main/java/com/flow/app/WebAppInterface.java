package com.flow.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

public class WebAppInterface {
  private final Context ctx;

  WebAppInterface(Context context) {
    this.ctx = context;
  }

  // id: stable string id per to-do / timer (used to cancel later)
  // title/body: notification text
  // triggerAtMillis: absolute epoch time in ms when it should fire
  @JavascriptInterface
  public void scheduleAlarm(String id, String title, String body, long triggerAtMillis) {
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;

    int notifId = id.hashCode();
    Intent intent = new Intent(ctx, AlarmReceiver.class);
    intent.putExtra("title", title);
    intent.putExtra("body", body);
    intent.putExtra("notifId", notifId);

    PendingIntent pi = PendingIntent.getBroadcast(
        ctx, notifId, intent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (am.canScheduleExactAlarms()) {
          am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        } else {
          am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        }
      } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
      }
    } catch (SecurityException e) {
      // Missing exact-alarm permission; fall back to inexact so it still fires eventually.
      am.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
    }
  }

  @JavascriptInterface
  public void cancelAlarm(String id) {
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;
    int notifId = id.hashCode();
    Intent intent = new Intent(ctx, AlarmReceiver.class);
    PendingIntent pi = PendingIntent.getBroadcast(
        ctx, notifId, intent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    am.cancel(pi);
  }

  // Lets JS check whether exact alarms are allowed (Android 12+) and prompt the user if not.
  @JavascriptInterface
  public boolean canScheduleExactAlarms() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
      return am != null && am.canScheduleExactAlarms();
    }
    return true;
  }

  @JavascriptInterface
  public void openExactAlarmSettings() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
      intent.setData(Uri.parse("package:" + ctx.getPackageName()));
      intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      ctx.startActivity(intent);
    }
  }

  @JavascriptInterface
  public boolean hasNotificationPermission() {
    return androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled();
  }

  @JavascriptInterface
  public void openNotificationSettings() {
    Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
    intent.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.getPackageName());
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    ctx.startActivity(intent);
  }
}
