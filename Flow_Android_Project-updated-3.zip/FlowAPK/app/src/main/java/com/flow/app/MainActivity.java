package com.flow.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private WebView webView;
  private String pendingExportJson;
  private static final int REQ_EXPORT = 2001;
  private static final int REQ_IMPORT = 2002;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
        && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
    }
    webView = new WebView(this);
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setAllowFileAccess(true);
    s.setLoadWithOverviewMode(true);
    s.setUseWideViewPort(true);
    s.setBuiltInZoomControls(false);
    webView.setInitialScale(125);
    webView.setWebChromeClient(new WebChromeClient());
    webView.addJavascriptInterface(new WebAppInterface(this), "AndroidBridge");
    AlarmReceiver.ensureChannel(this);
    AlarmReceiver.ensureAlarmChannel(this);
    webView.loadUrl("file:///android_asset/index.html");
    setContentView(webView);
  }
  @Override public void onBackPressed() {
    if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
  }

  void startExport(String json) {
    pendingExportJson = json;
    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("application/json");
    intent.putExtra(Intent.EXTRA_TITLE, "flow-backup.json");
    startActivityForResult(intent, REQ_EXPORT);
  }

  void startImport() {
    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("application/json");
    startActivityForResult(intent, REQ_IMPORT);
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (resultCode != RESULT_OK || data == null || data.getData() == null) {
      if (requestCode == REQ_EXPORT || requestCode == REQ_IMPORT) {
        webView.evaluateJavascript("window.onBackupCancelled && window.onBackupCancelled()", null);
      }
      return;
    }
    Uri uri = data.getData();
    if (requestCode == REQ_EXPORT) {
      try (OutputStream os = getContentResolver().openOutputStream(uri)) {
        if (os != null && pendingExportJson != null) {
          os.write(pendingExportJson.getBytes(StandardCharsets.UTF_8));
        }
        webView.evaluateJavascript("window.onBackupExported && window.onBackupExported()", null);
      } catch (Exception e) {
        webView.evaluateJavascript("window.onBackupError && window.onBackupError('export failed')", null);
      }
    } else if (requestCode == REQ_IMPORT) {
      try (BufferedReader reader = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri), StandardCharsets.UTF_8))) {
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        String escaped = sb.toString().replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n");
        webView.evaluateJavascript("window.onBackupImported && window.onBackupImported('" + escaped + "')", null);
      } catch (Exception e) {
        webView.evaluateJavascript("window.onBackupError && window.onBackupError('import failed')", null);
      }
    }
  }
}
