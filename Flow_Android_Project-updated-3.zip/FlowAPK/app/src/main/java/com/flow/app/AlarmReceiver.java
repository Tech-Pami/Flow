package com.flow.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.NotificationCompat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public class AlarmReceiver extends BroadcastReceiver {
  public static final String CHANNEL_ID = "flow_reminders";
  public static final String ALARM_CHANNEL_ID = "flow_alarms";

  @Override
  public void onReceive(Context context, Intent intent) {
    String title = intent.getStringExtra("title");
    String body = intent.getStringExtra("body");
    int notifId = intent.getIntExtra("notifId", 0);
    int hour = intent.getIntExtra("hour", -1);
    int minute = intent.getIntExtra("minute", 0);
    String daysCsv = intent.getStringExtra("daysCsv");
    boolean isAlarm = intent.getBooleanExtra("isAlarm", false);
    if (title == null) title = "Flow";
    if (body == null) body = "";

    ensureChannel(context);
    ensureAlarmChannel(context);

    Intent launchIntent = new Intent(context, MainActivity.class);
    launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent contentIntent = PendingIntent.getActivity(
        context, notifId, launchIntent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

    String channel = isAlarm ? ALARM_CHANNEL_ID : CHANNEL_ID;
    NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channel)
        .setSmallIcon(android.R.drawable.ic_popup_reminder)
        .setContentTitle(title)
        .setContentText(body.isEmpty() ? "Alarm" : body)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setCategory(isAlarm ? NotificationCompat.CATEGORY_ALARM : NotificationCompat.CATEGORY_REMINDER)
        .setAutoCancel(true)
        .setContentIntent(contentIntent);

    NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    if (nm != null) nm.notify(notifId, builder.build());

    // Repeating alarms re-arm their own next occurrence here, so they keep firing
    // even if the app never gets reopened.
    if (isAlarm && daysCsv != null && !daysCsv.isEmpty()) {
      long next = nextTrigger(hour, minute, daysCsv);
      AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
      if (am != null) {
        Intent reIntent = new Intent(context, AlarmReceiver.class);
        reIntent.putExtra("title", title);
        reIntent.putExtra("body", body);
        reIntent.putExtra("notifId", notifId);
        reIntent.putExtra("hour", hour);
        reIntent.putExtra("minute", minute);
        reIntent.putExtra("daysCsv", daysCsv);
        PendingIntent rePi = PendingIntent.getBroadcast(
            context, notifId, reIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, rePi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, rePi);
          } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, rePi);
          } else {
            am.setExact(AlarmManager.RTC_WAKEUP, next, rePi);
          }
        } catch (SecurityException e) {
          am.set(AlarmManager.RTC_WAKEUP, next, rePi);
        }
      }
    }
  }

  // Computes the next trigger time (epoch millis) strictly after "now" for the given
  // hour/minute, optionally restricted to a comma-separated set of weekdays
  // (0=Sunday..6=Saturday, matching JS Date#getDay()). Empty/null daysCsv = next occurrence
  // of that time, today or tomorrow.
  public static long nextTrigger(int hour, int minute, String daysCsv) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.SECOND, 0);
    cal.set(Calendar.MILLISECOND, 0);
    cal.set(Calendar.HOUR_OF_DAY, hour);
    cal.set(Calendar.MINUTE, minute);
    long now = System.currentTimeMillis();

    if (daysCsv == null || daysCsv.trim().isEmpty()) {
      if (cal.getTimeInMillis() <= now) cal.add(Calendar.DAY_OF_YEAR, 1);
      return cal.getTimeInMillis();
    }

    Set<Integer> days = new HashSet<>();
    for (String p : daysCsv.split(",")) {
      String t = p.trim();
      if (!t.isEmpty()) days.add(Integer.parseInt(t));
    }
    for (int i = 0; i < 8; i++) {
      int dow = cal.get(Calendar.DAY_OF_WEEK) - 1; // Calendar: 1=Sun..7=Sat -> 0=Sun..6=Sat
      if (cal.getTimeInMillis() > now && days.contains(dow)) {
        return cal.getTimeInMillis();
      }
      cal.add(Calendar.DAY_OF_YEAR, 1);
    }
    return cal.getTimeInMillis();
  }

  static void ensureChannel(Context context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
      if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID, "Flow reminders", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("To-do due date reminders");
        channel.enableVibration(true);
        channel.setLightColor(Color.parseColor("#7c6cff"));
        nm.createNotificationChannel(channel);
      }
    }
  }

  // Separate channel for the Alarms tab: uses the device's actual alarm sound
  // (not the default notification sound) plus a stronger vibration pattern.
  static void ensureAlarmChannel(Context context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
      if (nm != null && nm.getNotificationChannel(ALARM_CHANNEL_ID) == null) {
        NotificationChannel channel = new NotificationChannel(
            ALARM_CHANNEL_ID, "Flow alarms", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Alarms you've set in the Alarms tab");
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{0, 500, 250, 500, 250, 500});
        Uri alarmSound = Settings.System.DEFAULT_ALARM_ALERT_URI;
        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();
        channel.setSound(alarmSound, attrs);
        channel.setLightColor(Color.parseColor("#ff6ec7"));
        nm.createNotificationChannel(channel);
      }
    }
  }
}
