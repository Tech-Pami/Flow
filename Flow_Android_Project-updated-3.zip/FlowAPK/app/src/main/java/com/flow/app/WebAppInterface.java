package com.flow.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

public class WebAppInterface {
  private final Context ctx;

  WebAppInterface(Context context) {
    this.ctx = context;
  }

  // id: stable string id per to-do / timer (used to cancel later)
  // title/body: notification text
  // triggerAtMillis: absolute epoch time in ms when it should fire
  // Plain reminder — quiet notification channel, not the loud alarm sound.
  @JavascriptInterface
  public void scheduleAlarm(String id, String title, String body, long triggerAtMillis) {
    scheduleAtInternal(id, title, body, triggerAtMillis, -1, -1, null, false);
  }

  // Real one-off alarm at an exact date+time (used when a Plan block or To-do has its
  // alarm toggle turned on) — uses the same loud alarm channel/sound as the Alarms tab,
  // it just doesn't repeat since it's tied to one specific date.
  @JavascriptInterface
  public void scheduleDateAlarm(String id, String title, String body, long triggerAtMillis) {
    scheduleAtInternal(id, title, body, triggerAtMillis, -1, -1, null, true);
  }

  // Real repeating alarm (used by the Alarms tab). daysCsv is a comma-separated list of
  // weekdays (0=Sunday..6=Saturday), or empty for a one-time alarm. Computes the next
  // matching trigger time itself, and AlarmReceiver re-arms the following occurrence
  // when it fires, so it keeps repeating without the app needing to be reopened.
  @JavascriptInterface
  public void scheduleRepeatingAlarm(String id, String title, String body, int hour, int minute, String daysCsv) {
    long trigger = AlarmReceiver.nextTrigger(hour, minute, daysCsv);
    scheduleAtInternal(id, title, body, trigger, hour, minute, daysCsv, true);
  }

  private void scheduleAtInternal(String id, String title, String body, long triggerAtMillis, int hour, int minute, String daysCsv, boolean isAlarm) {
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;

    int notifId = id.hashCode();
    Intent intent = new Intent(ctx, AlarmReceiver.class);
    intent.putExtra("title", title);
    intent.putExtra("body", body);
    intent.putExtra("notifId", notifId);
    intent.putExtra("isAlarm", isAlarm);
    if (hour >= 0) {
      intent.putExtra("hour", hour);
      intent.putExtra("minute", minute);
      intent.putExtra("daysCsv", daysCsv == null ? "" : daysCsv);
    }

    PendingIntent pi = PendingIntent.getBroadcast(
        ctx, notifId, intent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (am.canScheduleExactAlarms()) {
          am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        } else {
          am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        }
      } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
      } else {
        am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
      }
    } catch (SecurityException e) {
      // Missing exact-alarm permission; fall back to inexact so it still fires eventually.
      am.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
    }
  }

  @JavascriptInterface
  public void cancelAlarm(String id) {
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;
    int notifId = id.hashCode();
    Intent intent = new Intent(ctx, AlarmReceiver.class);
    PendingIntent pi = PendingIntent.getBroadcast(
        ctx, notifId, intent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    am.cancel(pi);
  }

  // Lets JS check whether exact alarms are allowed (Android 12+) and prompt the user if not.
  @JavascriptInterface
  public boolean canScheduleExactAlarms() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
      return am != null && am.canScheduleExactAlarms();
    }
    return true;
  }

  @JavascriptInterface
  public void openExactAlarmSettings() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
      intent.setData(Uri.parse("package:" + ctx.getPackageName()));
      intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      ctx.startActivity(intent);
    }
  }

  @JavascriptInterface
  public boolean hasNotificationPermission() {
    return androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled();
  }

  @JavascriptInterface
  public void openNotificationSettings() {
    Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
    intent.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.getPackageName());
    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    ctx.startActivity(intent);
  }

  @JavascriptInterface
  public void exportBackup(String json) {
    if (ctx instanceof MainActivity) ((MainActivity) ctx).startExport(json);
  }

  @JavascriptInterface
  public void importBackup() {
    if (ctx instanceof MainActivity) ((MainActivity) ctx).startImport();
  }
}
