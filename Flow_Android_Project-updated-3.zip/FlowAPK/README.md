# Flow Android APK

This project wraps the Flow HTML app as an Android app and uses the supplied book image as the launcher icon.

## Build with GitHub Actions
1. Create a new GitHub repository named Flow.
2. Upload all files from this project, preserving folders.
3. Open the Actions tab and run **Build Flow APK**.
4. After it finishes, open the workflow run and download the **Flow-APK** artifact.
5. Extract the downloaded ZIP and install `app-debug.apk` on your Android tablet.
