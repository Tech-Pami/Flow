package com.flow.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BlockActivity extends Activity {
  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setGravity(Gravity.CENTER);
    root.setBackgroundColor(Color.parseColor("#0f0f14"));
    root.setPadding(60, 60, 60, 60);

    TextView icon = new TextView(this);
    icon.setText("\uD83D\uDD12");
    icon.setTextSize(56);
    icon.setGravity(Gravity.CENTER);
    root.addView(icon);

    TextView title = new TextView(this);
    title.setText("Blocked during Focus session");
    title.setTextColor(Color.WHITE);
    title.setTextSize(22);
    title.setTypeface(null, Typeface.BOLD);
    title.setGravity(Gravity.CENTER);
    title.setPadding(0, 40, 0, 16);
    root.addView(title);

    String pkg = getIntent().getStringExtra("blockedPackage");
    TextView sub = new TextView(this);
    sub.setText("This app is paused" + (pkg != null ? " (" + pkg + ")" : "") + " until your Focus session ends.");
    sub.setTextColor(Color.parseColor("#9a9aa5"));
    sub.setTextSize(14);
    sub.setGravity(Gravity.CENTER);
    sub.setPadding(20, 0, 20, 40);
    root.addView(sub);

    Button back = new Button(this);
    back.setText("Back to Flow");
    back.setAllCaps(false);
    back.setTextColor(Color.WHITE);
    back.setBackgroundColor(Color.parseColor("#7c6cff"));
    back.setPadding(48, 28, 48, 28);
    back.setOnClickListener(v -> {
      Intent i = new Intent(this, MainActivity.class);
      i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
      startActivity(i);
      finish();
    });
    root.addView(back);

    setContentView(root);
  }

  @Override public void onBackPressed() {
    // Don't let back-button dismiss into the blocked app; send home instead.
    Intent i = new Intent(Intent.ACTION_MAIN);
    i.addCategory(Intent.CATEGORY_HOME);
    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    startActivity(i);
    finish();
  }
}
