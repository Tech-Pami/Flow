package com.flow.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class FocusStopReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context, Intent intent) {
    context.stopService(new Intent(context, FocusService.class));
    context.getSharedPreferences(FocusService.PREFS, Context.MODE_PRIVATE)
        .edit().putBoolean("active", false).apply();
  }
}
