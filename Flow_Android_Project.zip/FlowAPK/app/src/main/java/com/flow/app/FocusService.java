package com.flow.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import java.util.HashSet;
import java.util.Set;

public class FocusService extends Service {
  public static final String PREFS = "flow_focus";
  public static final String CHANNEL_ID = "flow_focus";
  private static final int NOTIF_ID = 9001;
  private static final long POLL_MS = 1500;

  private Handler handler;
  private Runnable poller;
  private Set<String> blocked = new HashSet<>();
  private long endTime = 0;
  private String lastBlockedShown = "";

  @Override public void onCreate() {
    super.onCreate();
    handler = new Handler(Looper.getMainLooper());
  }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
    if (intent != null && intent.hasExtra("packages")) {
      String pkgsJson = intent.getStringExtra("packages");
      endTime = intent.getLongExtra("endTime", 0);
      blocked = jsonToSet(pkgsJson);
      prefs.edit().putString("packages", pkgsJson).putLong("endTime", endTime).putBoolean("active", true).apply();
      scheduleAutoStop(endTime);
    } else {
      // Service restarted by system; restore state from prefs.
      endTime = prefs.getLong("endTime", 0);
      blocked = jsonToSet(prefs.getString("packages", "[]"));
    }

    startForeground(NOTIF_ID, buildNotification());
    startPolling();
    return START_STICKY;
  }

  private void scheduleAutoStop(long when) {
    AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
    if (am == null) return;
    Intent stop = new Intent(this, FocusStopReceiver.class);
    PendingIntent pi = PendingIntent.getBroadcast(this, 9002, stop,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi); }
    catch (SecurityException e) { am.set(AlarmManager.RTC_WAKEUP, when, pi); }
  }

  private Set<String> jsonToSet(String json) {
    Set<String> s = new HashSet<>();
    try {
      JSONArray arr = new JSONArray(json);
      for (int i = 0; i < arr.length(); i++) s.add(arr.getString(i));
    } catch (Exception ignored) {}
    return s;
  }

  private Notification buildNotification() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
      if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
        android.app.NotificationChannel ch = new android.app.NotificationChannel(
            CHANNEL_ID, "Flow Focus session", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(ch);
      }
    }
    Intent openIntent = new Intent(this, MainActivity.class);
    PendingIntent contentIntent = PendingIntent.getActivity(this, 0, openIntent,
        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    return new NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_lock_lock)
        .setContentTitle("Focus session active")
        .setContentText("Blocked apps are paused until your session ends.")
        .setOngoing(true)
        .setContentIntent(contentIntent)
        .build();
  }

  private void startPolling() {
    if (poller != null) handler.removeCallbacks(poller);
    poller = new Runnable() {
      @Override public void run() {
        if (System.currentTimeMillis() >= endTime) { stopSelf(); return; }
        String fg = currentForegroundPackage();
        if (fg != null && blocked.contains(fg) && !fg.equals(getPackageName())) {
          if (!fg.equals(lastBlockedShown)) {
            lastBlockedShown = fg;
            Intent block = new Intent(FocusService.this, BlockActivity.class);
            block.putExtra("blockedPackage", fg);
            block.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(block);
          }
        } else {
          lastBlockedShown = "";
        }
        handler.postDelayed(this, POLL_MS);
      }
    };
    handler.post(poller);
  }

  private String currentForegroundPackage() {
    UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
    if (usm == null) return null;
    long end = System.currentTimeMillis();
    long start = end - 10000;
    UsageEvents events = usm.queryEvents(start, end);
    String last = null;
    UsageEvents.Event e = new UsageEvents.Event();
    while (events.hasNextEvent()) {
      events.getNextEvent(e);
      if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
        last = e.getPackageName();
      }
    }
    return last;
  }

  @Override public void onDestroy() {
    super.onDestroy();
    if (handler != null && poller != null) handler.removeCallbacks(poller);
    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("active", false).apply();
  }

  @Override public IBinder onBind(Intent intent) { return null; }
}
